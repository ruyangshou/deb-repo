
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was plexus_third_parties_exprtkConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

set(_plexus_exprtk_include_dir "${PACKAGE_PREFIX_DIR}/include/plexus/third_parties/exprtk")

if(NOT TARGET plexus_third_parties::exprtk)
    add_library(plexus_third_parties::exprtk INTERFACE IMPORTED)
    set_target_properties(plexus_third_parties::exprtk PROPERTIES
        INTERFACE_INCLUDE_DIRECTORIES "${_plexus_exprtk_include_dir}"
    )
endif()

unset(_plexus_exprtk_include_dir)
