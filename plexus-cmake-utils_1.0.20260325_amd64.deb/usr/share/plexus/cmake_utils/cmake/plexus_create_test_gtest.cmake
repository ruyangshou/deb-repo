function(plexus_create_test_gtest test_source_file)

    if (NOT TARGET GTest::GTest AND NOT DEFINED GTEST_LIBRARIES)
        message(FATAL_ERROR "Google Test (gtest) is not available. Please install or add it to your project.")
    endif ()

    add_executable(${test_source_file} ${ARGN})
    target_link_libraries(${test_source_file} ${PROJECT_NAME} ${GTEST_LIBRARIES} ${GTEST_BOTH_LIBRARIES} pthread)
    add_test(
            NAME test/${PROJECT_NAME}/${test_source_file}
            COMMAND ${test_source_file}
            WORKING_DIRECTORY "${CMAKE_BINARY_DIR}"
    )
endfunction()
