CMAKE_GENERATOR_NAME = Unix Makefiles
TIME_COMMAND = /usr/bin/time --format "buildtime: real=%e user=%U sys=%S [ %C ]"

STAGING_BUILD_TYPE = RelWithDebInfo
RELEASE_BUILD_TYPE = RelWithDebInfo
DEBUG_BUILD_TYPE = Debug

BUILD_DIR = build
INSTALL_DIR = opt

STAGING_DIR = staging
RELEASE_DIR = $(shell echo "${RELEASE_BUILD_TYPE}" | tr '[:upper:]' '[:lower:]')
DEBUG_DIR = $(shell echo "${DEBUG_BUILD_TYPE}" | tr '[:upper:]' '[:lower:]')

NUM_JOBS ?= 4

BUILD_COMMAND = $(MAKE) --jobs $(NUM_JOBS) --no-print-directory
BUILD_ID ?= "latest"
BUILD_UID := $(shell id -u)
WORKSPACE ?= $(abspath $(shell pwd)/..)

# The list of files which should trigger a re-cmake. Captured via:
# find * -name CMakeLists.txt -or -name '*.cmake' | sort | sed -e '$ ! s/$/ \\/' -e '2,$ s/^/\t/'
CMAKE_DEPS = CMakeLists.txt \

.ONESHELL:

# Default to debug build
all: debug

${BUILD_DIR}/${RELEASE_DIR}/Makefile: $(CMAKE_DEPS)
	@ $(eval LOGFILE=$(shell echo cmake-`date +%Y%m%dT%H%M%S`.log))
	@ $(info build: configuring ${RELEASE_BUILD_TYPE} build via cmake [log: ${BUILD_DIR}/${RELEASE_DIR}/${LOGFILE}]...)
	@ mkdir -p ${BUILD_DIR}/${RELEASE_DIR}
	@ cd ${BUILD_DIR}/${RELEASE_DIR}
	@ $(TIME_COMMAND) cmake ../.. -DCMAKE_EXPORT_COMPILE_COMMANDS=ON -DCMAKE_BUILD_TYPE="${RELEASE_BUILD_TYPE}" -G"$(CMAKE_GENERATOR_NAME)" > ${LOGFILE} 2>&1 && (echo "release cmake SUCCEEDED") || (/usr/bin/tail -25 ${LOGFILE}; echo "release cmake FAILED"; exit 1)

.PHONY: release
release: ${BUILD_DIR}/${RELEASE_DIR}/Makefile
	@ $(eval LOGFILE=$(shell echo build-`date +%Y%m%dT%H%M%S`.log))
	@ $(info build: building ${RELEASE_BUILD_TYPE} [log: ${BUILD_DIR}/${RELEASE_DIR}/${LOGFILE}]...)
	@ $(TIME_COMMAND) $(BUILD_COMMAND) -C "${BUILD_DIR}/${RELEASE_DIR}" 2>&1 && (echo "release build SUCCEEDED") || (echo "release build FAILED"; exit 1) | tee ${BUILD_DIR}/${RELEASE_DIR}/build-`date +%Y%m%dT%H%M%S`.log
	@ cd ${BUILD_DIR}
	@ rm -f latest
	@ /bin/ln -s ${RELEASE_DIR} latest

${BUILD_DIR}/${DEBUG_DIR}/Makefile: $(CMAKE_DEPS)
	@ $(eval LOGFILE=$(shell echo cmake-`date +%Y%m%dT%H%M%S`.log))
	@ $(info build: configuring ${DEBUG_BUILD_TYPE} build via cmake [log: ${BUILD_DIR}/${DEBUG_DIR}/${LOGFILE}]...)
	@ mkdir -p ${BUILD_DIR}/${DEBUG_DIR}
	@ cd ${BUILD_DIR}/${DEBUG_DIR}
	@ $(TIME_COMMAND) cmake ../.. -DCMAKE_EXPORT_COMPILE_COMMANDS=ON -DCMAKE_BUILD_TYPE="${DEBUG_BUILD_TYPE}" -G"$(CMAKE_GENERATOR_NAME)" > ${LOGFILE} 2>&1 && (echo "debug cmake SUCCEEDED") || (/usr/bin/tail -25 ${LOGFILE}; echo "debug cmake FAILED"; exit 1)

.PHONY: debug
debug: ${BUILD_DIR}/${DEBUG_DIR}/Makefile
	@ $(eval LOGFILE=$(shell echo build-`date +%Y%m%dT%H%M%S`.log))
	@ $(info build: building ${DEBUG_BUILD_TYPE} [log: ${BUILD_DIR}/${DEBUG_DIR}/${LOGFILE}]...)
	@ $(TIME_COMMAND) $(BUILD_COMMAND) -C "${BUILD_DIR}/${DEBUG_DIR}" 2>&1 && (echo "debug build SUCCEEDED") || (echo "debug build FAILED"; exit 1) | tee ${BUILD_DIR}/${DEBUG_DIR}/build-`date +%Y%m%dT%H%M%S`.log
	@ cd ${BUILD_DIR}
	@ rm -f latest
	@ /bin/ln -s "${DEBUG_DIR}" latest

${BUILD_DIR}/${STAGING_DIR}/Makefile: $(CMAKE_DEPS)
	@ $(eval LOGFILE=$(shell echo cmake-`date +%Y%m%dT%H%M%S`.log))
	@ $(info build: configuring STAGING (${STAGING_BUILD_TYPE}) build via cmake [log: ${BUILD_DIR}/${STAGING_DIR}/${LOGFILE}]...)
	@ mkdir -p ${BUILD_DIR}/${STAGING_DIR}
	@ cd ${BUILD_DIR}/${STAGING_DIR}
	@ $(TIME_COMMAND) cmake ../.. -DCMAKE_EXPORT_COMPILE_COMMANDS=ON -DSTAGING:BOOL=ON -DCMAKE_BUILD_TYPE="${STAGING_BUILD_TYPE}" -G"$(CMAKE_GENERATOR_NAME)" > ${LOGFILE} 2>&1 && (echo "cmake SUCCEEDED") || (/usr/bin/tail -25 ${LOGFILE}; echo "cmake FAILED"; exit 1)

.PHONY: staging
staging: ${BUILD_DIR}/${STAGING_DIR}/Makefile
	@ $(eval LOGFILE=$(shell echo build-`date +%Y%m%dT%H%M%S`.log))
	@ $(info build: building STAGING (${STAGING_BUILD_TYPE}) [log: ${BUILD_DIR}/${STAGING_DIR}/${LOGFILE}]...)
	@ $(TIME_COMMAND) $(BUILD_COMMAND) -C "${BUILD_DIR}/${STAGING_DIR}" 2>&1 && (echo "staging SUCCEEDED") || (echo "staging FAILED"; exit 1) | tee ${BUILD_DIR}/${STAGING_DIR}/build-`date +%Y%m%dT%H%M%S`.log
	@ cd ${BUILD_DIR}
	@ rm -f latest
	@ /bin/ln -s "${STAGING_DIR}" latest

.PHONY: install
install:
	@ $(info build: installing latest build...)
	@ $(TIME_COMMAND) $(BUILD_COMMAND) -C "${BUILD_DIR}/latest" install

.PHONY: test
test:
	@ $(info build: testing latest build...)
	@ $(TIME_COMMAND) $(BUILD_COMMAND) -C "${BUILD_DIR}/latest" CTEST_OUTPUT_ON_FAILURE=1 check

.PHONY: package
package: release
	@ $(info build: packaging ${RELEASE_BUILD_TYPE} build...)
	@ $(TIME_COMMAND) $(BUILD_COMMAND) -C "${BUILD_DIR}/${RELEASE_DIR}" package && (echo "package SUCCEEDED") || (echo "release FAILED at package"; exit 1)

.PHONY: clean
clean:
	@ $(TIME_COMMAND) rm -rf "${BUILD_DIR}" && (echo "clean SUCCEEDED") || (echo "clean FAILED"; exit 1)
	@ $(info build: outputs cleaned.)

CMAKE_DEPS := $(shell find * \( -name CMakeLists.txt -or -name '*.cmake' \) -not \( -path "${BUILD_DIR}/*" -o -path "${INSTALL_DIR}/*" -o -path ".git/*" \) | sort)
