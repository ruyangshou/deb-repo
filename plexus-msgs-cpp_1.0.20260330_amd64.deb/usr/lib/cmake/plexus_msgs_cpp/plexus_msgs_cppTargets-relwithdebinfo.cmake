#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "plexus::plexus_msgs_cpp" for configuration "RelWithDebInfo"
set_property(TARGET plexus::plexus_msgs_cpp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(plexus::plexus_msgs_cpp PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libplexus_msgs_cpp.so"
  IMPORTED_SONAME_RELWITHDEBINFO "libplexus_msgs_cpp.so"
  )

list(APPEND _cmake_import_check_targets plexus::plexus_msgs_cpp )
list(APPEND _cmake_import_check_files_for_plexus::plexus_msgs_cpp "${_IMPORT_PREFIX}/lib/libplexus_msgs_cpp.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
