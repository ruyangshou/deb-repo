# ------------------------------------------------------------------------------
# Make execution settings
# ------------------------------------------------------------------------------

SHELL := /bin/bash
.SHELLFLAGS := -eu -o pipefail -c
.ONESHELL:

# ------------------------------------------------------------------------------
# User-configurable build settings
# ------------------------------------------------------------------------------

BUILD_TYPE ?= RelWithDebInfo
BUILD_DIR ?= build
BUILD_ID ?= latest

INSTALL_DIR ?= opt

TARGET ?=
COMPONENT ?=
COMPONENT := $(or $(COMPONENT),$(TARGET))

NUM_JOBS ?= 4
WITH_COVERAGE ?= OFF

# ------------------------------------------------------------------------------
# CMake settings
# ------------------------------------------------------------------------------

CMAKE_GENERATOR_NAME ?= Unix Makefiles
CMAKE_BUILD_NATIVE_ARGS := -- --no-print-directory

# ------------------------------------------------------------------------------
# Tooling
# ------------------------------------------------------------------------------

TIME_COMMAND := /usr/bin/time --format "buildtime: real=%e user=%U sys=%S [ %C ]"

# ------------------------------------------------------------------------------
# Derived paths and variables
# ------------------------------------------------------------------------------

BUILD_DIR_NAME := $(shell echo "$(BUILD_TYPE)" | tr '[:upper:]' '[:lower:]')
BUILD_PATH := $(BUILD_DIR)/$(BUILD_DIR_NAME)

INSTALL_PREFIX := $(abspath $(INSTALL_DIR))

# ------------------------------------------------------------------------------
# Targets
# ------------------------------------------------------------------------------

.PHONY: all configure build debug release install test package clean

all: build

configure:
	@ $(eval LOG_FILE=$(shell date +cmake-%Y%m%dT%H%M%S.log))
	@ $(info build: configuring $(BUILD_TYPE) build via cmake [log: $(BUILD_PATH)/$(LOG_FILE)]...)
	@ mkdir -p "$(BUILD_PATH)"
	@ $(TIME_COMMAND) cmake \
		-S . \
		-B "$(BUILD_PATH)" \
		-DCMAKE_BUILD_TYPE="$(BUILD_TYPE)" \
		-DCMAKE_INSTALL_PREFIX="$(INSTALL_PREFIX)" \
		-DWITH_COVERAGE="$(WITH_COVERAGE)" \
		-G"$(CMAKE_GENERATOR_NAME)" \
		--no-warn-unused-cli \
		2>&1 | tee "$(BUILD_PATH)/$(LOG_FILE)"

build: configure
	@ $(eval LOG_FILE=$(shell date +build-%Y%m%dT%H%M%S.log))
	@ $(info build: building $(BUILD_TYPE) [log: $(BUILD_PATH)/$(LOG_FILE)]...)
	@ {
		if [ -n "$(TARGET)" ]; then
			$(TIME_COMMAND) cmake \
				--build "$(BUILD_PATH)" \
				--parallel "$(NUM_JOBS)" \
				--target "$(TARGET)" \
				$(CMAKE_BUILD_NATIVE_ARGS) \
				2>&1 | tee "$(BUILD_PATH)/$(LOG_FILE)"
		else
			$(TIME_COMMAND) cmake \
				--build "$(BUILD_PATH)" \
				--parallel "$(NUM_JOBS)" \
				$(CMAKE_BUILD_NATIVE_ARGS) \
				2>&1 | tee "$(BUILD_PATH)/$(LOG_FILE)"
		fi
	}
	@ /bin/ln -sfnT "$(BUILD_DIR_NAME)" "$(BUILD_DIR)/$(BUILD_ID)"

debug:
	@ $(MAKE) -f $(MAKEFILE_LIST) --no-print-directory build BUILD_TYPE=Debug

release:
	@ $(MAKE) -f $(MAKEFILE_LIST) --no-print-directory build BUILD_TYPE=RelWithDebInfo

install:
	@ $(info build: installing $(BUILD_ID) build...)
	@ {
		if [ -n "$(COMPONENT)" ]; then
			$(TIME_COMMAND) cmake \
				--install "$(BUILD_DIR)/$(BUILD_ID)" \
				--prefix "$(INSTALL_PREFIX)" \
				--component "$(COMPONENT)"
		else
			$(TIME_COMMAND) cmake \
				--install "$(BUILD_DIR)/$(BUILD_ID)" \
				--prefix "$(INSTALL_PREFIX)"
		fi
	}

test:
	@ $(info build: testing $(BUILD_ID) build...)
	@ {
		if [ -n "$(TARGET)" ]; then
			echo "build: warning: test on specific target not yet supported."
		else
			$(TIME_COMMAND) ctest \
				--test-dir "$(BUILD_DIR)/$(BUILD_ID)" \
				--output-on-failure \
				--no-tests=ignore \
				-j "$(NUM_JOBS)"
			if [ "$(WITH_COVERAGE)" = "ON" ]; then
				$(TIME_COMMAND) cmake \
					--build "$(BUILD_DIR)/$(BUILD_ID)" \
					--parallel "$(NUM_JOBS)" \
					--target coverage \
					$(CMAKE_BUILD_NATIVE_ARGS)
			fi
		fi
	}

package: release
	@ $(info build: packaging RelWithDebInfo build...)
	@ {
		if [ -n "$(COMPONENT)" ]; then
			echo "build: warning: package on specific component/target not yet supported.";
		else
			$(TIME_COMMAND) cpack --config "$(BUILD_DIR)/$(BUILD_ID)/CPackConfig.cmake";
		fi
	}

clean:
	@ $(TIME_COMMAND) rm -rf "$(BUILD_DIR)"
	@ $(info build: outputs cleaned.)
