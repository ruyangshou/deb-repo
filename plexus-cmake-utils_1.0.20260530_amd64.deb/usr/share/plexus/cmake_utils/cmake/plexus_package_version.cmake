function(plexus_package_version version_var)

    set(version_file "${CMAKE_CURRENT_SOURCE_DIR}/VERSION")
    if (NOT EXISTS ${version_file})
        message(FATAL_ERROR "VERSION file not found at ${version_file}")
        return()
    endif ()

    file(READ ${version_file} version_string)
    string(STRIP "${version_string}" version_string)

    # Try to match major.minor.patch
    string(REGEX MATCH "^(0|[1-9][0-9]*)\\.(0|[1-9][0-9]*)\\.(0|[1-9][0-9]*)$" full_matched ${version_string})
    if (full_matched)
        set(version ${version_string})
    else ()
        # Try to match major.minor
        string(REGEX MATCH "^(0|[1-9][0-9]*)\\.(0|[1-9][0-9]*)$" full_matched ${version_string})
        if (full_matched)
            set(major_minor_version ${version_string})
            set(patch_version "99999999") # default
            if (DEFINED ENV{BUILD_NUMBER})
                set(patch_version "$ENV{BUILD_NUMBER}")
            endif ()
            set(version "${major_minor_version}.${patch_version}")
        else ()
            message(WARNING "Version string '${version_string}' in VERSION file has unknown format. Using it as is.")
            set(version ${version_string})
        endif ()
    endif ()

    set(${version_var} ${version} PARENT_SCOPE)
endfunction()
