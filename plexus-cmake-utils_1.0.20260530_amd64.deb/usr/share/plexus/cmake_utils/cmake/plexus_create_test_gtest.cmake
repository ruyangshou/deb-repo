function(plexus_create_test_gtest test_name test_source_file)

    if (NOT TARGET GTest::GTest OR NOT TARGET GTest::Main OR NOT TARGET Threads::Threads)
        message(FATAL_ERROR "Google Test and Threads libraries are required to create tests. Please make sure to find_package(GTest REQUIRED) and find_package(Threads REQUIRED) before calling plexus_create_test_gtest.")
    endif ()

    include(GoogleTest)

    add_executable(${test_name} ${test_source_file} ${ARGN})
    target_link_libraries(${test_name} ${PROJECT_NAME} GTest::GTest GTest::Main Threads::Threads)
    gtest_discover_tests(${test_name})
endfunction()
