function(plexus_protobuf_make_proto_dir_args proto_dir_args_var)
    set(${proto_dir_args_var})

    foreach (proto_dir ${ARGN})
        get_filename_component(abs_proto_dir ${proto_dir} ABSOLUTE)
        list(FIND ${proto_dir_args_var} ${abs_proto_dir} found)
        if (${found} EQUAL -1)
            list(APPEND ${proto_dir_args_var} --proto_path ${abs_proto_dir})
        endif ()
    endforeach ()

    if (DEFINED PROTOBUF_IMPORT_DIRS)
        foreach (proto_dir ${PROTOBUF_IMPORT_DIRS})
            get_filename_component(abs_proto_dir ${proto_dir} ABSOLUTE)
            list(FIND ${proto_dir_args_var} ${abs_proto_dir} found)
            if (${found} EQUAL -1)
                list(APPEND ${proto_dir_args_var} --proto_path ${abs_proto_dir})
            endif ()
        endforeach ()
    endif ()

    set(${proto_dir_args_var} ${${proto_dir_args_var}} PARENT_SCOPE)
endfunction()


function(plexus_protobuf_generate_codes source_files_var header_files_var output_dir proto_dir)

    if (NOT DEFINED PROTOBUF_PROTOC_EXECUTABLE OR NOT EXISTS "${PROTOBUF_PROTOC_EXECUTABLE}")
        message(FATAL_ERROR "PROTOBUF_PROTOC_EXECUTABLE is not set or does not exist.")
    endif ()

    set(${source_files_var})
    set(${header_files_var})

    plexus_protobuf_make_proto_dir_args(proto_dir_args ${proto_dir})

    get_filename_component(abs_proto_dir ${proto_dir} ABSOLUTE)
    file(GLOB_RECURSE proto_files "${proto_dir}/*.proto")

    foreach (proto_file ${proto_files})
        get_filename_component(abs_proto_file ${proto_file} ABSOLUTE)
        get_filename_component(proto_file_name ${proto_file} NAME_WE)
        get_filename_component(proto_file_dir ${proto_file} PATH)

        file(RELATIVE_PATH namespace_path ${abs_proto_dir} ${proto_file_dir})

        set(code_gen_dir "${output_dir}/${namespace_path}")
        set(source_file "${code_gen_dir}/${proto_file_name}.pb.cc")
        set(header_file "${code_gen_dir}/${proto_file_name}.pb.h")

        list(APPEND ${source_files_var} ${source_file})
        list(APPEND ${header_files_var} ${header_file})
        add_custom_command(
                OUTPUT ${source_file} ${header_file}
                COMMAND ${CMAKE_COMMAND} -E make_directory ${output_dir}
                COMMAND ${PROTOBUF_PROTOC_EXECUTABLE} --cpp_out ${output_dir} ${proto_dir_args} ${proto_file}
                DEPENDS ${proto_file}
                COMMENT "Running Protocol Buffer compiler on target '${proto_file}'"
                VERBATIM
        )

        string(REPLACE "/" "-" target_name "protobuf_generate-${PROJECT_NAME}-${namespace_path}-${proto_file_name}")
        add_custom_target(${target_name} DEPENDS ${source_file} ${header_file})
    endforeach ()

    set_source_files_properties(${${source_files_var}} ${${header_files_var}} PROPERTIES GENERATED TRUE)
    set(${source_files_var} ${${source_files_var}} PARENT_SCOPE)
    set(${header_files_var} ${${header_files_var}} PARENT_SCOPE)
endfunction()
