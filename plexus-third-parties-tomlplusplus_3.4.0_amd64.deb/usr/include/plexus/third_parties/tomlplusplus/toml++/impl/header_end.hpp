//# {{
#ifdef __INTELLISENSE__
#include "preprocessor.hpp"
#endif
//# }}
#ifdef _MSC_VER
#pragma pop_macro("min")
#pragma pop_macro("max")
#ifndef __clang__
#pragma inline_recursion(off)
#endif
#endif
TOML_POP_WARNINGS;
