
// AUTO-GENERATED FILE. DO NOT EDIT.
#pragma once


namespace plexus::msgs {


class PlexusMsgTailor {
public:

    static void TailorMessage(::plexus::msgs::testing::DummyMessage &message) {
        message.clear_omitted_optional_int32();
        message.clear_omitted_repeated_int32();
        message.clear_omitted_optional_int64();
        message.clear_omitted_repeated_int64();
        message.clear_omitted_optional_double();
        message.clear_omitted_repeated_double();
        message.clear_omitted_optional_bool();
        message.clear_omitted_repeated_bool();
        message.clear_omitted_optional_string();
        message.clear_omitted_repeated_string();
        message.clear_omitted_optional_enum();
        message.clear_omitted_repeated_enum();
        message.clear_omitted_optional_timestamp();
        message.clear_omitted_repeated_timestamp();
        message.clear_omitted_optional_nested_message();
        message.clear_omitted_repeated_nested_message();
        if (message.has_optional_nested_message()) {
            PlexusMsgTailor::TailorMessage(*message.mutable_optional_nested_message());
        }
        for (int i = 0; i < message.mutable_repeated_nested_message()->size(); ++i) {
            PlexusMsgTailor::TailorMessage(message.mutable_repeated_nested_message()->at(i));
        }
    }


    static void TailorMessage(::plexus::msgs::testing::DummyMessage::NestedDummyMessage &message) {
        message.clear_omitted_optional_int32();
        message.clear_omitted_repeated_int32();
        message.clear_omitted_optional_int64();
        message.clear_omitted_repeated_int64();
        message.clear_omitted_optional_double();
        message.clear_omitted_repeated_double();
        message.clear_omitted_optional_bool();
        message.clear_omitted_repeated_bool();
        message.clear_omitted_optional_string();
        message.clear_omitted_repeated_string();
        message.clear_omitted_optional_enum();
        message.clear_omitted_repeated_enum();
        message.clear_omitted_optional_timestamp();
        message.clear_omitted_repeated_timestamp();
    }


    static void TailorMessage(::plexus::msgs::testing::AnotherDummyMessage &message) {
        if (message.has_optional_nested_message()) {
            PlexusMsgTailor::TailorMessage(*message.mutable_optional_nested_message());
        }
        for (int i = 0; i < message.mutable_repeated_nested_message()->size(); ++i) {
            PlexusMsgTailor::TailorMessage(message.mutable_repeated_nested_message()->at(i));
        }
    }


    static void TailorMessage(::plexus::msgs::testing::AnotherDummyMessage::NestedDummyMessage &message) {
        message.clear_omitted_optional_int32();
        message.clear_omitted_repeated_int32();
        message.clear_omitted_optional_int64();
        message.clear_omitted_repeated_int64();
        message.clear_omitted_optional_double();
        message.clear_omitted_repeated_double();
        message.clear_omitted_optional_bool();
        message.clear_omitted_repeated_bool();
        message.clear_omitted_optional_string();
        message.clear_omitted_repeated_string();
        message.clear_omitted_optional_enum();
        message.clear_omitted_repeated_enum();
        message.clear_omitted_optional_timestamp();
        message.clear_omitted_repeated_timestamp();
        message.clear_omitted_optional_message();
        message.clear_omitted_repeated_message();
        if (message.has_optional_message()) {
            PlexusMsgTailor::TailorMessage(*message.mutable_optional_message());
        }
        for (int i = 0; i < message.mutable_repeated_message()->size(); ++i) {
            PlexusMsgTailor::TailorMessage(message.mutable_repeated_message()->at(i));
        }
    }


    template <typename T>
    static auto Tailor(const T &message) {
        return message;
    }
};


template <>
auto PlexusMsgTailor::Tailor(const ::plexus::msgs::testing::DummyMessage &message) {
    auto copy = message;
    PlexusMsgTailor::TailorMessage(copy);
    return copy;
}


template <>
auto PlexusMsgTailor::Tailor(const ::plexus::msgs::testing::DummyMessage::NestedDummyMessage &message) {
    auto copy = message;
    PlexusMsgTailor::TailorMessage(copy);
    return copy;
}


template <>
auto PlexusMsgTailor::Tailor(const ::plexus::msgs::testing::AnotherDummyMessage &message) {
    auto copy = message;
    PlexusMsgTailor::TailorMessage(copy);
    return copy;
}


template <>
auto PlexusMsgTailor::Tailor(const ::plexus::msgs::testing::AnotherDummyMessage::NestedDummyMessage &message) {
    auto copy = message;
    PlexusMsgTailor::TailorMessage(copy);
    return copy;
}


} // namespace plexus::msgs